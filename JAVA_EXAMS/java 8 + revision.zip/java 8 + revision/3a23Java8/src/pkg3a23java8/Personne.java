/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pkg3a23java8;

/**
 *
 * @author bhk
 */
public class Personne {
    private int age;
    private String nom;

    public Personne() {
    }

    public Personne(int age, String nom) {
        this.age = age;
        this.nom = nom;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    @Override
    public String toString() {
        return "Personne{" + "age=" + age + ", nom=" + nom + '}';
    }
    
    
}
