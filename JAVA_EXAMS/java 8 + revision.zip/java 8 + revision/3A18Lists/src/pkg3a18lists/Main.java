/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pkg3a18lists;

import entities.EspritArrayList;
import entities.Etudiant;

/**
 *
 * @author bhk
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Etudiant e1 = new Etudiant(0, "aa", "aa");
        Etudiant e2 = new Etudiant(1, "cc", "cc");
        Etudiant e3 = new Etudiant(3, "bb", "bb");
        Etudiant e4 = new Etudiant(2, "dd", "dd");

        EspritArrayList esprit = new EspritArrayList();

        esprit.ajouterEtudiant(e1);
        esprit.ajouterEtudiant(e2);
        esprit.ajouterEtudiant(e3);
        esprit.ajouterEtudiant(e4);
        
        System.out.println("Avant TRIE");
        esprit.displayEtudiants();
        
        System.out.println("TRIE  ID");
        esprit.trierEtudiantsParId();
        esprit.displayEtudiants();
        
        System.out.println("TRIE  NOM");
        esprit.trierEtudiantsParNom();
        esprit.displayEtudiants();
        
        
    }

}
